VERSION = "3.7.4"

if __name__ == "__main__":
    print(VERSION, end="")  # noqa: T201
